package passengers;

import java.util.Scanner;

public class passengerMain {

	public static void runPassenger() {
		Scanner scan = new Scanner(System.in);
		passenger_Linkedlist passengers = new passenger_Linkedlist();

		System.out.println("Do you have an account? (yes/no)");
		String answer = scan.next();

		if (answer.equalsIgnoreCase("yes")) {

			System.out.println("Enter your name:");
			String name = scan.next();
			System.out.println("Enter your password:");
			String password = scan.next();

			//hon saret ashallak eza baddak tb3at l passenger bl edit
			//bass eza baddak tredda bool 3a ra7tak ma7a kharreb ba2a 
			passenger foundPassenger = passengers.searchPassengerByNameAndPassword(name, password);
			//hon btsir !=null
			if (foundPassenger != true) {

				System.out.println("Welcome, " + name + "!");
				int number = 0;
				while (number != -1) {
					System.out.println("\n1-Edit your account ");
					System.out.println("2-delete your account");
					System.out.println("3-display your  account  ");
					System.out.println("-1 Exit");
					number = scan.nextInt();
					switch (number) {
					case 1:
						//hon btsir tb3at l found passenger
						passengers.editPassengerAccount(name, password);
						break;
					case 2:
						//hon kamen
						passengers.deletePassengerByNameWithConfirmation(name);
						break;
					case 3:
						//hon kamen
						passengers.displayPassengerInfo(name, password);
						break;
					
					}

				}
			} else {
				System.out.println("Invalid name or password. Please try again.");
			}
		} else {

			System.out.println("Enter your name:");
			String name = scan.next();
			System.out.println("Enter your account balance:");
			int balance = scan.nextInt();
			System.out.println("Enter your password:");
			String password = scan.next();
			int pn;
			do {
				System.out.print("Enter your phone number: ");
				pn = scan.nextInt();

				if (String.valueOf(pn).length() != 8) {
					System.out.println("Error: Phone number must have exactly 8 digits. Please re-enter.");
				}
			} while (String.valueOf(pn).length() != 8);
			// hon lezem ten3amal linked list passengers
			//kermel ysir ye2dar ya3mel aktar mn account wl constructor already byekhod passenger bl flight 
			//so bass ychtre l ticket btna2es mn l balance w bta3mello add 3al flight l na22eha
			//w ma tnsa baddak tjma3on b main wa7ad kl l mains
			//ykoun 5000 line ma btfro2 lmohem ykoun arya7 la elna
			//wma tnsa tsta3mel method take seat bl airplane lamma tkoun seat take
			//w eza ma2elak khele2 ensa 3melon random seat bass se3eta ma77e hay l method mn airlane wl seats matrix kamen
			passenger newPassenger = new passenger(name, balance, password, pn);
			passengers.insertAtFront(newPassenger);
			System.out.println("Account created successfully!");
		}
	}
}
