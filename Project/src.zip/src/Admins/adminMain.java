package Admins;

import java.util.Scanner;

import airport_Man_System.Flight;
import airport_Man_System.Flight_Node;
import airport_Man_System.Priorityqueue;

public class adminMain {

	public void runAdmin() {
		Scanner scan = new Scanner(System.in);
		adminQueue admins = new adminQueue();
		Priorityqueue Flightqueue = new Priorityqueue();
		System.out.println("Do you have an account? (yes/no)");
		String answer = scan.next();
		if (answer.equalsIgnoreCase("yes")) {
			System.out.println("Please enter your ID: ");
			int id = scan.nextInt();
			System.out.println("Please enter the password: ");
			String password = scan.next();

			System.out.println("Checking account...");
			if ((admins.checkAccount(id, password))) {
				System.out.println("Account doesn't match. Please retry.");
			} else {
				System.out.println("Welcome, admin!");
				int number = 0;
				while (number != -1) {

					System.out.println("\n1-edit account");
					System.out.println("2-display all the admins");
					System.out.println("3-delete admin by his Id");
					System.out.println("4-add Flight Plan");
					System.out.println("5-update Flight Plan");
					System.out.println("6-delete Flight Plan");
					System.out.println("7-display Flight Plans");
					System.out.println("8-add new admin");
					System.out.println("9-Search for an admin by his id ");
					System.out.println("-1 to exit");
					number = scan.nextInt();
					switch (number) {
					case 1:
						admins.editAccountInfo();
						break;
					case 2:
						admins.displayAllAdmins();
						break;
					case 3:
						System.out.println("Enter the ID of the admin you want to delete:");
						int deleteId = scan.nextInt();
						admins.deleteAdminById(deleteId);
						break;
					case 4:
						Flight flight = new Flight();
						Flightqueue.insertAtBack(flight, 0 /* Flight Priority */);
						break;
					case 5:
						System.out.println("Enter the flight id");
						int fid = scan.nextInt();
						Flight_Node x = Flightqueue.searchFlightById(fid);
						if (x != null) {
							Flight flight2 = new Flight();
							x.getData().edit(flight2);
						} else
							System.out.println("Flight Not Found!");
						break;
					case 6:
						System.out.println("Enter the flight id to delete\nWARNING: This action cannot be undone!");
						int fid2 = scan.nextInt();
						if (Flightqueue.searchFlightById(fid2) != null)
							Flightqueue.deleteFlightById(fid2);
						else
							System.out.println("Flight Not Found!");
						break;
					case 7:
						Flightqueue.display();
						break;
					case 8:
						System.out.print("Enter your first name: ");
						String fn = scan.next();
						System.out.print("Enter your last name: ");
						String ln = scan.next();
						System.out.print("Enter your phone number: ");
						int pn = scan.nextInt();
						System.out.println("Enter your password : ");
						String pass = scan.next();
						admin newAdmin = new admin(fn, ln, pn, pass);
						System.out.println("Admin id is: " + newAdmin.getId());
						admins.enqueue(newAdmin);
						break;
					case 9:
						System.out.println("Enter the id for the admin you want to search about  ");
						int searchByAdminId = scan.nextInt();
						admin foundAdmin = admins.searchById(searchByAdminId);

						if (foundAdmin != null) {
							System.out.println("Admin with id " + searchByAdminId + " is " + foundAdmin.getFirstName());

							System.out.print("And this phone number is : " + foundAdmin.getPhoneNumber());
						} else {
							System.out.println("Admin with id 2 not found");
						}

						break;

					default:
						System.out.println("invalid number");
						break;
					}
				}

			}

		} else {
			System.out.print("Enter your first name: ");
			String fn = scan.next();
			System.out.print("Enter your last name: ");
			String ln = scan.next();
			int pn;

			do {
				System.out.print("Enter your phone number: ");
				pn = scan.nextInt();

				if (String.valueOf(pn).length() != 8) {
					System.out.println("Error: Phone number must have exactly 8 digits. Please re-enter.");
				}
			} while (String.valueOf(pn).length() != 8);

			System.out.print("Enter your password: ");
			String pass = scan.next();

			admin newAdmin = new admin(fn, ln, pn, pass);
			System.out.println("Admin id is: " + newAdmin.getId());
			admins.enqueue(newAdmin);
			System.out.println();

		}

	}

}
