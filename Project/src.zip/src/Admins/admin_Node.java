package Admins;

public class admin_Node {
	admin_Node next;
	admin data;

	public admin_Node(admin data) {
		this.next = null;
		this.data = data;
	}

}
