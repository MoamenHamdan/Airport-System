package airport_Man_System;

import java.util.Scanner;

import Admins.admin;
import Admins.adminMain;
import Admins.adminQueue;
import passengers.passengerMain;

public class main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		adminMain adminMain =new adminMain();
		passengerMain passengerMain= new passengerMain();
		
		System.out.println("\t\t\tWelcome to our Airport Managnment System");
		System.out.println("\t\t\t****************************************");
		int choice = 0;
		while (choice != -1) {
			System.out.println("----------------------------------");
			System.out.println("Enter Your choice: ");
			System.out.println("1)Admin");
			System.out.println("2)User");
			System.out.println("-1)Quit");
			System.out.println("----------------------------------");
			choice = scan.nextInt();
			System.out.println();
			switch (choice) {
			case 1:
				adminMain.runAdmin();
				break;

			case 2:
				passengerMain.runPassenger();
				break;
			default:
				System.out.println("Invalid input");
				break;

			}

		}

	}
}
