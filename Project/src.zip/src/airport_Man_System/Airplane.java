package airport_Man_System;

public class Airplane {

	private int id;
	private int numberOfSeats;
	private boolean[][] seatsMatrix;

	public Airplane(int id, int numberOfSeats) {
		this.id = id;
		this.numberOfSeats = numberOfSeats;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getNumberOfSeats() {
		return numberOfSeats;
	}

	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}

	public void initializeSeatsMatrix(int totalSeats) {
		seatsMatrix = new boolean[totalSeats / 3 + 1][3];
		int seatNumber = 1;
		for (int i = 0; i < seatsMatrix.length; i++) {
			for (int j = 0; j < seatsMatrix[i].length; j++) {
				if (seatNumber <= totalSeats) {
					seatsMatrix[i][j] = true; // true means seat is available
					seatNumber++;
				}
			}
		}
	}

	public void displaySeatingArrangement() {
		for (int i = 0; i < seatsMatrix.length; i++) {
			for (int j = 0; j < seatsMatrix[i].length; j++) {
				if (seatsMatrix[i][j]) {
					System.out.print((i * 3 + j + 1) + " ");
				} else {
					System.out.print("x ");
				}
			}
			System.out.println();
		}
	}

	public void takeSeat(int seatNumber) {
		int row = (seatNumber - 1) / 3;
		int col = (seatNumber - 1) % 3;
		seatsMatrix[row][col] = false; // mark seat as taken
	}
}
