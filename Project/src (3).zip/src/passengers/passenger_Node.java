package passengers;

public class passenger_Node {
	passenger_Node next;
	passenger data;
	public passenger_Node(passenger data){
		this.data=data;
		next=null;
	}

}
