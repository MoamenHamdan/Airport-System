package passengers;

import java.util.Scanner;

public class passengerMain {

	public static void runPassenger() {
		Scanner scan = new Scanner(System.in);
		

		
	}
}
