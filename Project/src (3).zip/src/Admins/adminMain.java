package Admins;

import java.util.Scanner;

import airport_Man_System.Flight;
import airport_Man_System.Flight_Node;
import airport_Man_System.Priorityqueue;

public class adminMain {

	public void runAdmin() {
		Scanner scan = new Scanner(System.in);
	}
}
